
#define INITIALIZATION_INCLUDE
#include <Arduino.h>
#include "initialization.h"
#include "simulation.h"
#include "boolean.h"
#include "TCBStruct.h"
#include "TCBfunctions.h"
#include "dataStructs.h"
#include "dataTypes.h"

// Declare and assign initial sensor data

unsigned int temperatureRaw = 75;
unsigned int systolicPressRaw = 80;
unsigned int diastolicPressRaw = 81;
unsigned int pulseRateRaw = 50;
unsigned char tempCorrected = NULL;
unsigned char systolicPressCorrected = NULL;
unsigned char diastolicPressCorrected = NULL;
unsigned char pulseRateCorrected = NULL;
unsigned short batteryState = 200;
Bool bpOutOfRange = 0;
Bool tempOutOfRange = 0;
Bool pulseOutOfRange = 0;
Bool bpHigh = FALSE;
Bool tempHigh = FALSE;
Bool pulseLow = FALSE;
TCB measureDataTask;
TCB computeDataTask;
TCB warningAlarmTask;
TCB displayDataTask;
TCB updateBatteryStatusTask;
TCB* taskQueue[6];


void something(){
    // Declare and assign data structs
    /*Serial.print("tempRaw value before measure initialization: ");
    Serial.println(temperatureRaw);*/
    measureDataStruct meaDataStruct;
    meaDataStruct.tempRaw = &temperatureRaw;
    /*Serial.print("batteryState value after measure initialization: ");
    Serial.println(temperatureRaw);*/
    meaDataStruct.systolicPressRaw = &systolicPressRaw;
    meaDataStruct.diastolicPressRaw = &diastolicPressRaw;
    meaDataStruct.pulseRateRaw = &pulseRateRaw;
    
    computeDataStruct comDataStruct;
    /*Serial.print("tempRaw value before compute initialization: ");
    Serial.println(temperatureRaw);*/
    comDataStruct.tempRaw = &temperatureRaw;
    /*Serial.print("tempRaw value in compute initialization: ");
    Serial.println(temperatureRaw);*/
    comDataStruct.systolicPressRaw = &systolicPressRaw;
    comDataStruct.diastolicPressRaw = &diastolicPressRaw;
    comDataStruct.pulseRateRaw = &pulseRateRaw;
    comDataStruct.tempCorrected = &tempCorrected;
    comDataStruct.systolicPressCorrected = &systolicPressCorrected;
    comDataStruct.diastolicCorrected = &diastolicPressCorrected;
    comDataStruct.pulseRateCorrected = &pulseRateCorrected;
    
    warningAlarmStruct warnAlarmDataStruct;
    /*
    unsigned char* tempCorrected;
    unsigned char* systolicPressCorrected;
    unsigned char* diastolicCorrected;
    unsigned char* pulseRateCorrected;
    unsigned short*  batteryState;
    Bool* bpOutOfRange;
    Bool* tempOutOfRange;
    Bool* pulseOutOfRange;
    Bool* bpHigh;
    Bool* tempHigh;
    Bool* pulseLow;
    */
    warnAlarmDataStruct.tempCorrected = &tempCorrected;
    warnAlarmDataStruct.systolicPressCorrected = &systolicPressCorrected;
    warnAlarmDataStruct.diastolicCorrected = &diastolicPressCorrected;
    warnAlarmDataStruct.pulseRateCorrected = &pulseRateCorrected;
    warnAlarmDataStruct.batteryState = &batteryState;
    Serial.print("batteryState value in warning initialization: ");
    Serial.println(batteryState);
    warnAlarmDataStruct.bpOutOfRange = &bpOutOfRange;
    warnAlarmDataStruct.tempOutOfRange = &tempOutOfRange;
    warnAlarmDataStruct.pulseOutOfRange = &pulseOutOfRange;
    warnAlarmDataStruct.bpHigh = &bpHigh;
    warnAlarmDataStruct.tempHigh = &tempHigh;
    warnAlarmDataStruct.pulseLow = &pulseLow;
    
    displayDataStruct disDataStruct;
    /*
    unsigned char* tempCorrected;
    unsigned char* systolicPressCorrected;
    unsigned char* diastolicCorrected;
    unsigned char* pulseRateCorrected;
    unsigned short*  batteryState;
    Bool* bpOutOfRange;
    Bool* tempOutOfRange;
    Bool* pulseOutOfRange;
    Bool* bpHigh;
    Bool* tempHigh;
    Bool* pulseLow;
    */
    Serial.print("batteryState value in before display initialization: ");
    Serial.println(batteryState);
    disDataStruct.tempCorrected = &tempCorrected;
    disDataStruct.systolicPressCorrected = &systolicPressCorrected;
    disDataStruct.diastolicCorrected = &diastolicPressCorrected;
    disDataStruct.pulseRateCorrected = &pulseRateCorrected;
    disDataStruct.batteryState = &batteryState;
    Serial.print("batteryState value in display initialization: ");
    Serial.println(batteryState);
    disDataStruct.bpOutOfRange = &bpOutOfRange;
    disDataStruct.tempOutOfRange = &tempOutOfRange;
    disDataStruct.pulseOutOfRange = &pulseOutOfRange;
    disDataStruct.bpHigh = &bpHigh;
    disDataStruct.tempHigh = &tempHigh;
    disDataStruct.pulseLow = &pulseLow;
    Serial.print("batteryState value before update initialization: ");
    Serial.println(batteryState);
    updateStatusStruct updateStatStruct;
    updateStatStruct.batteryState = &batteryState;
    Serial.print("batteryState value in update initialization: ");
    Serial.println(batteryState);
    // Declare and assign task control blocks
    
    measureDataTask.taskFuncPtr = &measureData;
    measureDataTask.taskDataPtr = &meaDataStruct;
    
    computeDataTask.taskFuncPtr = &computeData;
    computeDataTask.taskDataPtr = &comDataStruct;
    
    warningAlarmTask.taskFuncPtr = &warningAlarm;
    warningAlarmTask.taskDataPtr = &warnAlarmDataStruct;
    
    displayDataTask.taskFuncPtr = &displayData;
    displayDataTask.taskDataPtr = &disDataStruct;
    
    updateBatteryStatusTask.taskFuncPtr = &updateBatteryStatus;
    updateBatteryStatusTask.taskDataPtr = &updateStatStruct;
    
    // Define array of TCB
    
    taskQueue[0] = &measureDataTask;
    taskQueue[1] = &computeDataTask;
    taskQueue[2] = &warningAlarmTask;
    taskQueue[3] = &displayDataTask;
    taskQueue[4] = &updateBatteryStatusTask;
    
}


