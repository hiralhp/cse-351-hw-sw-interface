#ifndef DATATYPES_INCLUDE
#define DATATYPES_INCLUDE

//// Define data type Boolean
//enum _myBool { FALSE = 0, TRUE = 1 };
//typedef enum _myBool Bool;
//
#endif


