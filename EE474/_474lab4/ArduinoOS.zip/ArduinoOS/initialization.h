//
//  initialization.h
//  simple
//
//  Created by Hiral Patel on 4/16/18.
//  Copyright (c) 2018 Hiral Patel. All rights reserved.
//
#include "TCBStruct.h"
#include "boolean.h"
#ifndef __simple__initialization__
#define __simple__initialization__


extern unsigned int temperatureRaw;
extern unsigned int systolicPressRaw;
extern unsigned int diastolicPressRaw;
extern unsigned int pulseRateRaw;
extern unsigned char tempCorrected;
extern unsigned char systolicPressCorrected;
extern unsigned char diastolicPressCorrected;
extern unsigned char pulseRateCorrected;
extern unsigned short batteryState;
extern Bool bpOutOfRange;
extern Bool tempOutOfRange;
extern Bool pulseOutOfRange;
extern Bool bpHigh;
extern Bool tempHigh;
extern Bool pulseLow;
extern TCB measureDataTask;
extern TCB computeDataTask;
extern TCB warningAlarmTask;
extern TCB displayDataTask;
extern TCB updateBatteryStatusTask;
extern TCB taskControlBlockStruct;
extern TCB* taskQueue[6];


  void something();

#endif /* defined(__simple__initialization__) */
