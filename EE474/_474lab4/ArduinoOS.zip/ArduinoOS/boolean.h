//
//  boolean.h
//  
//
//  Created by Hiral Patel on 4/16/18.
//
//

#ifndef _boolean_h
#define _boolean_h
enum _myBool { FALSE = 0, TRUE = 1 };
typedef enum _myBool Bool;

#endif
